<?php

    //데이터베이스 닫기
    mysqli_close($conn);

?>
    <!-- footer.php -->